let handler = m => m
handler.all = async function (m) {
global.alyapi = 'elsbiru213' // Alya Apikey
global.roseapi = 'yaU7nZmhh1tFirAE07TvJRl0yGD459jKF0EGKsvYCh7o1Jr9ojy3Zr3XlmB3mkro' // Rose Apikey
global.lolkey = 'Liberty' // Lolhuman Apikey
global.neoapi = 'Kemii' // Neoxr Apikey
}

module.exports = handler